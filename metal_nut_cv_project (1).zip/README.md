# Metal Nut Defect Detection

A compact CNN-based defect detector for the MVTec AD metal_nut dataset.

## Features
- Derives defect bounding boxes from segmentation masks.
- Predicts defect presence and a bounding box.
- Compares baseline training with an improved training experiment.
- Exports the model to ONNX for CPU inference.

## Model
Input: RGB image resized to 128x128.
Outputs: binary defect logits and normalized bounding-box coordinates.

## Results on the custom held-out split
| Metric | Baseline | Improved |
|---|---:|---:|
| Detection precision @ IoU 0.5 | 0.1613 | 0.2500 |
| Detection recall @ IoU 0.5 | 0.2632 | 0.3158 |
| mAP@0.5 (custom 101-point estimate) | 0.1256 | 0.1733 |
| Mean IoU | 0.3406 | 0.3358 |

ONNX CPU inference: approximately 1.218 ms/image (single-image model-only benchmark).

## Important evaluation note
These are results from a custom split, not the official MVTec AD benchmark protocol.
Defect images from the original test directory were divided between training,
validation and test subsets, so these metrics should not be presented as official
benchmark results. The small dataset and weak box localization are limitations.

## Files
- `improved_metal_nut_detector.pth`: trained PyTorch checkpoint
- `metal_nut_detector.onnx`: exported ONNX model
- `bounding_boxes.csv`: boxes derived from segmentation masks
- `train_manifest.csv`, `val_manifest.csv`, `test_manifest.csv`: dataset splits
- `metrics.json`: recorded evaluation metrics

## Future improvements
- Use a larger and more carefully separated dataset.
- Improve localization with a dedicated object-detection architecture.
- Evaluate with a standard detection evaluation library and official protocol.
